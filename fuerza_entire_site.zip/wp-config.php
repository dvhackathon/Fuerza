<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'crapacka_wrd12');

/** MySQL database username */
define('DB_USER', 'crapacka_wrd12');

/** MySQL database password */
define('DB_PASSWORD', 'OSoe7i6HOu');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'PosgQBRgz3sZlKmvqlyeqS11hB4hYzqWpW09NNTKs8CV8EobMJxRsmbkKdho34we');
define('SECURE_AUTH_KEY',  'ABhiYZxhHwxLprVjTpOs0LBatYjvc9muNSn0FX59c3YM4PzEKKovcHXRxpOFqVpa');
define('LOGGED_IN_KEY',    'DzOcHlo4upOuk8jyb5duO2wo2XVrEFl74xmVj5id5eP52FGoCcZGQaqmJPWltNF1');
define('NONCE_KEY',        'qEV2veSpVJfGcicnGdTbTTUS8dQp3FT96GkzKIeJaLol8kUSYr3vCoda74l1eamI');
define('AUTH_SALT',        'IndKw1xF7pDsgNzT6JmfdVA0FvXdlZxVQAUTg7PTg6pOE0UmQvrqkdXqmYMYKbjG');
define('SECURE_AUTH_SALT', 'i0xgBFq3dz7rfQSgWhaJEeg7gNWQvxb9U9ExSkTRPfhz6NE0Mhe3wz6PB0OM4uZ9');
define('LOGGED_IN_SALT',   'AnhfNVTFEofi0gjyYdA7Xb3W0ChNBEViIo1nFexm4z1S3wuGsUY1QmsOxJ70ATuo');
define('NONCE_SALT',       'gkuyk8suZPnVONKtSfTFOQ3xfXSBGRu2YOK3sJYggJfaS9pihwN5k26eDyATUmUT');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
